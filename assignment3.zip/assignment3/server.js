const express = require('express');

const path = require('path');
const fs = require("fs");


//const config = require("./config.json");
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.set("view engine", "pug");
//let RestaurantRouter=require("./Restaurant-router");
//app.use("./Add",RestaurantRouter);
let RestaurantsRouter=require("./Restaurants-router");
app.use("/Restaurants",RestaurantsRouter);
let addRestaurantsRouter=require("./addRestaurant-router");
app.use("/addrestaurant",addRestaurantsRouter);
app.get("/", (req, res, next)=> { res.render("pages/home"); });

app.get("/client.js", (req, res)=>{
    res.sendFile(__dirname+ '/views/pages/client.js')
})
/*
app.post("/Restaurants",(req,res)=>{
    
    console.log("post server "+req.body.name)
    res.send(req.body)
    var t = RestaurantsRouter.results;
    //console.log(t);


    
})*/






app.listen(3000);
console.log("Server listening at http://localhost:3000");