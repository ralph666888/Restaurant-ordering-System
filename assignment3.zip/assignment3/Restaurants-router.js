//const config = require("./config.json");
const express = require("express");
const path = require("path");
const fs = require("fs");
let router = express.Router();
let results = [];
let id=2;

router.put("/",[loadRestaurants, (req, res)=>{
  let d = results[req.body.id].menu
  for (let i of results){
   if (i.id == req.body.id){
      d = i.menu;
    }
  }

  for (let i in req.body.newStuff){
    for (let j of req.body.newStuff[i]){ 
      d[i][Object.keys(d[i]).length+ 1] = j
    }
  
  }
  debugger
}]);

router.post("/",(req,res)=>{
    
  console.log("name is "+ req.body.name)
  id++;
  let obj = req.body;
  obj.id=id;
  results.push(obj)
  
  
  console.log("body: ", req.body)
  req.body.menu = {}
  res.render("pages/Unique", { Restaurant: req.body,Id: req.body.id,name:req.body.name,
    order:req.body.min_order,fee:req.body.delivery_fee});
  
  
})

router.get("/:uid", [loadRestaurants, function(req, res){
  console.log("test : ", res.Restaurants[req.params.uid])
  res.render("pages/Unique", { Restaurant: res.Restaurants[req.params.uid],Id: req.params.uid,name:res.Restaurants[req.params.uid].name,
  order:res.Restaurants[req.params.uid].min_order,fee:res.Restaurants[req.params.uid].delivery_fee});
  
}]);

router.get("/", [loadRestaurants, respondRestaurants]);

/*router.get("/addrestaurant", function(req,res) {
  res.render("pages/addrestaurant")
})*/

function loadRestaurants(req, res, next) {
  //console.log("name is "+ req.body.name)
  //console.log("loadres");
  
  let items = fs.readdirSync("./restaurants/");

  items.forEach(function(item) {
    let rawdata = String(fs.readFileSync("./restaurants/" + item))
    let flag = false;
    for(let i=0;i<results.length;i++){
      if(results[i].id==JSON.parse(rawdata).id){
        flag = true;
        
      }
    }
    if(!flag){
    results.push(JSON.parse(rawdata));
    }
  });
  res.Restaurants = results;
  next();
}



function respondRestaurants(req, res, next) {
  res.format({
    "text/html": () => {

  debugger
      res.render("pages/Restaurants", { Restaurants: res.Restaurants});
    },
    "application/json": () => {
      res.status(200).json(res.Restaurants);
    }
  });
  next();
}


module.exports = router;
module.exports.results= results;
