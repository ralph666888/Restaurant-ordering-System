let restaurants={};
let restaurantname=["Aragorn's Orc BBQ", "Frodo's Flapjacks", 'Lembas by Legolas'];
let restaurant0=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
let restaurant1=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
let restaurant2=[0,0,0,0,0,0,0,0];
let pop=["","",""];

//Aragon:submitnum[0],be:submitnum[1],ce:submitnum[2]
//store each restaurants submit number;
let submitnum=[0,0,0];
let total=[0,0,0];
let average=[0,0,0];
let http = require('http');
let fs = require('fs');
let path = require('path');
const pug = require("pug");
let filepath = path.resolve('./restaurants');
let mimeLookup = {
	'.js': 'application/javascript',
	'.html': 'text/html',
	'.jpg': 'image/jpeg'
};
let f=0;
let a=0;
let b=0;
let c=0;
let d=0;
let u=0;
let array=[];
const renderHome = pug.compileFile('views/pages/home.pug');
const renderorder = pug.compileFile('views/pages/orderform.pug');
const renderStat = pug.compileFile("views/pages/stats.pug");



function send404(response) {
	response.writeHead(404, { 'Content-Type': 'text/plain' });
	response.write('Error 404: Resource not found.');
	response.end();
}
const server = http.createServer(function (req, response) {

if (req.method === 'GET') {
		// resolve file path to filesystem path
		if (req.url === '/'||req.url === '/home'){
      indexpage=renderHome({});
			response.statusCode=200;
			response.setHeader("Content-type","text/html");
			response.end(indexpage);
		}else if(req.url === '/client.js'){
			fs.readFile("./views/pages/client.js", function(err, data){
				if(err){
					send404(response);
					return;
				}
				response.statusCode = 200;
				response.setHeader("Content-Type", "application/javascript");
				response.end(data);
			});
		} else if(req.url === "/add.jpg"){
			fs.readFile("./views/add.jpg", function(err, data){
				if(err){
					send404(response);
					return;
				}
				response.statusCode = 200;
				response.setHeader("Content-Type","image/jpg");
				response.write(data);
				response.end();
		});
	} else if(req.url === "/remove.jpg"){
		fs.readFile("./views/remove.jpg", function(err, data){
			if(err){
				send404(response);
				return;
			}
			response.statusCode = 200;
			response.setHeader("Content-Type","image/jpg");
			response.write(data);
			response.end();
	});
} else if(req.url === "/orderform"){
			page=renderorder({});
			response.statusCode=200;
			response.setHeader("Content-type","text/html");
			response.end(page);
			// send array
		}

		else if(req.url==="/Stat"){
			//console.log(pop);
			let statpage=renderStat({restaurants:restaurants,
				submitnum:submitnum, average:average, pop:pop
			});
			response.statusCode=200;
			response.setHeader("Content-type","text/html");
			response.end(statpage);
		}


		else if(req.url === "/restaurants"){
			fs.readdir("./restaurants/", function(err, items) {
			  if (err) {
			    onError(err);
			    return;
			  }
				items.forEach(function(item) {
		      let resJSON=require("./restaurants/"+item)
					 restaurants[resJSON.name]=resJSON;

				});

				response.statusCode=200;
				response.setHeader("content-Type","application/json");
				response.write(JSON.stringify(restaurants))
				response.end();

				//Object.keys(restaurants).forEach(elem => {
           //restaurantname.push(elem);

				 //document.getElementById("left1").innerHTML+=elem;
				//});

			});

		}


	}

	 else if(req.method === "POST"){
	if(req.url==="/restaurants_a"){
    let body = ""
		req.on('data', (chunk) => {
			body += chunk;
		})
		req.on('end', () => {
			//console.log(JSON.parse(body));


			//console.log("body: " + body);
			//Send th body information back, just for fun
			response.statusCode = 200;
			//response.write(body);
			response.end();
			//submitnum=JSON.parse(body).ordernum;



		})

  }else if(req.url==="/order"){
    let body = ""
		req.on('data', (chunk) => {
			body += chunk;
		})
		req.on('end', () =>{
			response.statusCode = 200;
			response.end();
      submitnum[JSON.parse(body).Index]++;
			total[JSON.parse(body).Index]+=JSON.parse(body).total;
			for(let i=0;i<average.length;i++){
				average[i]=total[i]/submitnum[i];

			}

			console.log(JSON.parse(body).order);
			if(JSON.parse(body).Index===0){

			Object.keys(JSON.parse(body).order).forEach(id =>{
				restaurant0[id-""]+=JSON.parse(body).order[id];
      console.log(id-"");

	  	});
			console.log(restaurant0);
		}
		if(JSON.parse(body).Index==1){

		Object.keys(JSON.parse(body).order).forEach(id =>{
			restaurant1[id-""]+=JSON.parse(body).order[id];


		});
	}
	if(JSON.parse(body).Index==2){

	Object.keys(JSON.parse(body).order).forEach(id =>{
		restaurant2[id-""]+=JSON.parse(body).order[id];
     //console.log(id);

	});
}
for(let i=0;i<restaurant0.length;i++){
	if(restaurant0[i]>f){
		f=restaurant0[i];
		u=i;
	}

}
for(let i=0;i<restaurant1.length;i++){
	if(restaurant1[i]>a){
		a=restaurant1[i];
		b=i;
	}

}

for(let i=0;i<restaurant2.length;i++){
	if(restaurant2[i]>c){
		c=restaurant2[i];
		d=i;

	}

}

Object.keys(restaurants[restaurantname[0]]['menu']).forEach(k=>{
	Object.keys(restaurants[restaurantname[0]]['menu'][k]).forEach(g=>{
		if(restaurant0[0]!=0){
		if(g==u){
		pop[0]=restaurants[restaurantname[0]]['menu'][k][g].name;
	}
}});
});
Object.keys(restaurants[restaurantname[1]]['menu']).forEach(k=>{
	Object.keys(restaurants[restaurantname[1]]['menu'][k]).forEach(g=>{
		if(restaurant1[0]!=0){
		if(g==b){
		pop[1]=restaurants[restaurantname[1]]['menu'][k][g].name;
	}
}});
});
Object.keys(restaurants[restaurantname[2]]['menu']).forEach(k=>{
	Object.keys(restaurants[restaurantname[2]]['menu'][k]).forEach(g=>{
		if(restaurant2[0]!=0){
		if(g==d){

		pop[2]=restaurants[restaurantname[2]]['menu'][k][g].name;
	}
}});
});

			//console.log("Testing body of url /order");
			//console.log(body);
			//[1,0,0] worked



		})

  }

  else{ //if not a GET request, send 404
		send404(response);
	}

			//read the todo.html file and send it back

		}});

server.listen(3000);
console.log('Server running at http:/localhost:3000/');
