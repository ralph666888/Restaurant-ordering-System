Frist when you open load the page, it will show welcome message! when you open the browse restaurant it will show
three restaurants link and then if you add restaurant in restaurant page it will add restaurant and 
go back to the link it will show 4 restaurant. Then you can add category and item in the Unique page
Then when you add category it will show the information which you have add both in category select index
and also menu inner.HTML. then you add item it will show the right place down to the category.Then
you save the information it will save it to the server and render page!