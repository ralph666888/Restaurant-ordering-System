
let select
let input1
let input2
let newStuff = {}
let button1=document.getElementById("Addcategory")

let s=document.getElementById("Menu");

let d=document.getElementById("save");
document.getElementById("additem").onclick = addItem
window.onload = function init(){
	newStuff = {}
select = document.getElementById("restaurant-select");
input1=document.getElementById(1)
input2=document.getElementById(2)
input3=document.getElementById(3)
input4=document.getElementById(4)
    this.console.log(input1.value);
	 this.genDropDownList();
	
 }

 function genDropDownList(){
	//console.log("genDropdown list is working")


	let result = '<select name="restaurant-select" id="restaurant-select">';

  var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
 	 if (this.readyState == 4 && this.status == 200) {
		console.log(this.responseText);
		 temp = this.responseText;
		 //console.log(restaurants);
		 restaurants = JSON.parse(temp);
 		 console.log(restaurants);
 		 items=JSON.parse(this.response);
		 //console.log("resturant size is "+restaurants.length);
		 
	 	Object.keys(restaurants).forEach(elem => {
			if(elem==input1.value){
				
				Object.keys(restaurants[elem].menu).forEach(key => {
			 result += `<option value="${key}">${key}</option>`
			  
				});
			//document.getElementById("left1").innerHTML+=elem;
			}
	 	});
		 result += "</select>";
		 button1.onclick=addcategory;
		 select.innerHTML = result;
		 document.getElementById("save").onclick = save
		

 	 }
  }
  xhttp.open("GET", "http://127.0.0.1:3000/Restaurants");
	xhttp.setRequestHeader("Accept", "application/json");
	xhttp.send();
	}
	
function addcategory(){
  input2=document.getElementById("category");
  //debugger
  newStuff[input2.value] = []
  select.innerHTML+=`<option value='${input2.value}'">${input2.value}</option>`
  s.innerHTML+=`<b>${input2.value}</b>`+"<br>";
}
function addItem(){
  let newItem = {}
  let a = document.getElementById("name")
  let c = document.getElementById("description")
  let b = document.getElementById("price")
  newItem.name = a.value;
  newItem.description = c.value;
  newItem.price= b.value;
  

  let input2=document.getElementById("restaurant-select");
  let input = document.getElementById(input2.value);
  let s = `<p>${a.value} ${"$"+b.value}</p>`
   s += `<p>${c.value}</p></br>`
  input.innerHTML += s

  if (!newStuff[input2.value]){
	newStuff[input2.value] = []
  }
  newStuff[input2.value].push(newItem)
}
function save(){
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
 	if (this.readyState == 4 && this.status == 200) {
     
	
	
	}
}
	let data = {id:input1.value,name:input2.value,min_order:input3.value,delivery_fee:input4.value
	, }
	xhttp.open("PUT", "http://127.0.0.1:3000/Restaurants"); 
    xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
   
	xhttp.send(JSON.stringify(
		{id:input1.value,newStuff:newStuff})
	);
}
