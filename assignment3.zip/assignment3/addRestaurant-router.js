const express = require("express");
const path = require("path");
const fs = require("fs");
let router = express.Router();

router.get("/", function(req,res) {
    res.render("pages/addrestaurant")
  })

  module.exports = router;